/**
 * 
 */
/**
 * @author joaoe
 *
 */
module campeonato {
}